const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

app.get('/api/projects', (req, res) => {
  res.json([
    { id: 1, name: 'Sunrise Farm (Ghana)', tokenSymbol: 'SFARM', totalSupply: 1000000, priceUSD: 200000 },
    { id: 2, name: 'Coastal Orchards (Mexico)', tokenSymbol: 'COAST', totalSupply: 500000, priceUSD: 120000 }
  ])
})

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log('Backend running on http://localhost:' + PORT));
