import React, {useEffect, useState} from 'react'

export default function Dashboard(){
  const [projects, setProjects] = useState([])

  useEffect(()=>{
    fetch('http://localhost:4000/api/projects')
      .then(r=>r.json())
      .then(setProjects)
      .catch(()=>setProjects([]))
  },[])

  return (
    <div>
      <h2>Available Farm Projects</h2>
      <div style={{display:'grid',gap:12}}>
        {projects.length===0 && <div className="card">No projects (start backend)</div>}
        {projects.map(p=>(
          <div key={p.id} className="card">
            <h3>{p.name} — {p.tokenSymbol}</h3>
            <p>Total supply: {p.totalSupply}</p>
            <p>Price (USD): ${p.priceUSD}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
