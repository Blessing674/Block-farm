const hre = require('hardhat');

async function main() {
  const FarmToken = await hre.ethers.getContractFactory('FarmToken');
  const initialSupply = hre.ethers.utils.parseUnits('1000000', 18);
  const token = await FarmToken.deploy('Sunrise Farm Token', 'SFARM', initialSupply, 1);
  await token.deployed();
  console.log('FarmToken deployed to:', token.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
