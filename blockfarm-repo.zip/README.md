# BlockFarm

**BlockFarm** — Web3 platform connecting global investors to sustainable farmland via tokenization.

This repository is a starter template (Solidity + React + Node.js) for the BlockFarm project.
Generated on 2025-10-29.

## Quickstart (dev)

1. Install root deps (Hardhat uses local node): `npm install`
2. Compile & test smart contracts: `npx hardhat compile && npx hardhat test`
3. Deploy to local Hardhat: `npx hardhat node` (in new terminal), then `node scripts/deploy.js`
4. Start backend: `cd backend && npm install && npm run start`
5. Start frontend: `cd frontend && npm install && npm run dev`

## Folder structure

```
blockfarm-repo/
├─ contracts/
├─ scripts/
├─ frontend/
└─ backend/
```

## Notes
- This starter uses a simple ERC20 representing fractional farm ownership.
- Payouts/yield should be implemented using stablecoin contracts and an off-chain oracle in production.
- Replace environment placeholders in `.env` before deploying to public networks.
