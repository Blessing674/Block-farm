import React from 'react'
import Dashboard from './components/Dashboard'

export default function App(){
  return (
    <div className="app">
      <header className="header">
        <img src="/logo.svg" alt="BlockFarm logo" width={56} />
        <h1>BlockFarm</h1>
      </header>
      <main>
        <Dashboard />
      </main>
    </div>
  )
}
